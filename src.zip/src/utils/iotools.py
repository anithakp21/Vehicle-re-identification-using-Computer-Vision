# Copyright (c) EEEM071, University of Surrey

import errno
import json
import os
import os.path as osp
import warnings


def mkdir_if_missing(directory):
    if not osp.exists(directory):
        try:
            os.makedirs(directory)
        except OSError as e:
            if e.errno != errno.EEXIST:
                raise


def check_isfile(path):
    isfile = osp.isfile(path)
    if not isfile:
        warnings.warn(f'No file found at "{path}"')
    return isfile


def read_json(fpath):
    with open(fpath) as f:
        obj = json.load(f)
    return obj


def write_json(obj, fpath):
    mkdir_if_missing(osp.dirname(fpath))
    with open(fpath, "w") as f:
        json.dump(obj, f, indent=4, separators=(",", ": "))
